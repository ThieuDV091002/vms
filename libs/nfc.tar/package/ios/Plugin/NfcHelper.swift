import Foundation
import Capacitor
import CoreNFC

@available(iOS 13.0, *)
public class NfcHelper {

    public static func createReadingResultForNdefTag(tag: NFCTag, status: NFCNDEFStatus?, capacity: Int?, message: NFCNDEFMessage?) -> JSObject {
        var result = JSObject()
        var techTypes: [String] = []

        if let status = status {
            result["isWritable"] = status == NFCNDEFStatus.readWrite
        }
        if let capacity = capacity {
            result["maxSize"] = capacity
        }
        if let message = message {
            result["message"] = NfcHelper.createJsonObjectFromNdefMessage(message: message)
        }

        if NfcHelper.getNfcNdefTagFromNfcTag(tag: tag) != nil {
            techTypes.append("NDEF")
        }

        if let felicaTag = NfcHelper.getNfcFelicaTagFromNfcTag(tag: tag) {
            techTypes.append("NFC_F")
            result["type"] = "NFC_FORUM_TYPE_3"
            result["manufacturer"] = [UInt8](felicaTag.currentIDm)
            result["systemCode"] = [UInt8](felicaTag.currentSystemCode)
        }

        if let iso7816Tag = NfcHelper.getNfcIso7816TagFromNfcTag(tag: tag) {
            result["id"] = [UInt8](iso7816Tag.identifier)
            if let applicationData = iso7816Tag.applicationData {
                result["applicationData"] = [UInt8](applicationData)
            }
            if let historicalBytes = iso7816Tag.historicalBytes {
                result["historicalBytes"] = [UInt8](historicalBytes)
            }
        }

        if let iso15693Tag = NfcHelper.getNfcIso15693TagFromNfcTag(tag: tag) {
            result["id"] = [UInt8](iso15693Tag.identifier)
        }

        if let mifareTag = NfcHelper.getNfcMifareTagFromNfcTag(tag: tag) {
            result["id"] = [UInt8](mifareTag.identifier)
            if let historicalBytes = mifareTag.historicalBytes {
                result["historicalBytes"] = [UInt8](historicalBytes)
            }
            switch mifareTag.mifareFamily {
            case .desfire:
                techTypes.append("MIFARE_DESFIRE")
            case .plus:
                techTypes.append("MIFARE_PLUS")
            case .ultralight:
                techTypes.append("MIFARE_ULTRALIGHT")
            case .unknown: break
            @unknown default: break
            }
        }

        result["techTypes"] = techTypes

        return result
    }

    public static func getNfcNdefTagFromNfcTag(tag: NFCTag) -> NFCNDEFTag? {
        switch tag {
        case .feliCa(let ndefTag):
            return ndefTag
        case .miFare(let ndefTag):
            return ndefTag
        case .iso7816(let ndefTag):
            return ndefTag
        case .iso15693(let ndefTag):
            return ndefTag
        @unknown default:
            return nil
        }
    }

    public static func getNfcFelicaTagFromNfcTag(tag: NFCTag) -> NFCFeliCaTag? {
        switch tag {
        case .feliCa(let felicaTag):
            return felicaTag
        case .miFare:
            return nil
        case .iso7816:
            return nil
        case .iso15693:
            return nil
        @unknown default:
            return nil
        }
    }

    public static func getNfcMifareTagFromNfcTag(tag: NFCTag) -> NFCMiFareTag? {
        switch tag {
        case .feliCa:
            return nil
        case .miFare(let mifareTag):
            return mifareTag
        case .iso7816:
            return nil
        case .iso15693:
            return nil
        @unknown default:
            return nil
        }
    }

    public static func getNfcIso7816TagFromNfcTag(tag: NFCTag) -> NFCISO7816Tag? {
        switch tag {
        case .feliCa:
            return nil
        case .miFare:
            return nil
        case .iso7816(let iso7816Tag):
            return iso7816Tag
        case .iso15693:
            return nil
        @unknown default:
            return nil
        }
    }

    public static func getNfcIso15693TagFromNfcTag(tag: NFCTag) -> NFCISO15693Tag? {
        switch tag {
        case .feliCa:
            return nil
        case .miFare:
            return nil
        case .iso7816:
            return nil
        case .iso15693(let iso15693Tag):
            return iso15693Tag
        @unknown default:
            return nil
        }
    }

    public static func createNdefMessageFromJsonObject(json: JSObject) -> NFCNDEFMessage {
        let records = json["records"] as? [JSObject] ?? []
        return NFCNDEFMessage(records: records.map {
            var format: NFCTypeNameFormat = NFCTypeNameFormat.unknown
            if let tnfValue = $0["tnf"] as? Int {
                format = NFCTypeNameFormat(rawValue: UInt8(tnfValue)) ?? NFCTypeNameFormat.unknown
            }
            var type: Data = Data()
            if let typeValue = $0["type"] as? [Int] {
                type = Data(typeValue.map { UInt8($0) })
            }
            var identifier: Data = Data()
            if let idValue = $0["id"] as? [Int] {
                identifier = Data(idValue.map { UInt8($0) })
            }
            var payload: Data = Data()
            if let payloadValue = $0["payload"] as? [Int] {
                payload = Data(payloadValue.map { UInt8($0) })
            }
            return NFCNDEFPayload(
                format: format,
                type: type,
                identifier: identifier,
                payload: payload
            )
        })
    }

    private static func createJsonObjectFromNdefMessage(message: NFCNDEFMessage) -> JSObject {
        let records = NfcHelper.createJsonArrayFromNdefRecords(records: message.records)

        var result = JSObject()
        result["records"] = records
        return result
    }

    private static func createJsonArrayFromNdefRecords(records: [NFCNDEFPayload]) -> [JSObject] {
        return records.map { NfcHelper.createJsonObjectFromNdefRecord(record: $0) }
    }

    private static func createJsonObjectFromNdefRecord(record: NFCNDEFPayload) -> JSObject {
        var result = JSObject()
        result["id"] = [UInt8](record.identifier)
        result["type"] = [UInt8](record.type)
        result["payload"] = [UInt8](record.payload)
        result["tnf"] = record.typeNameFormat.rawValue as JSValue
        return result
    }
}
