import Foundation
import Capacitor

/**
 * Please read the Capacitor iOS Plugin Development Guide
 * here: https://capacitorjs.com/docs/plugins/ios
 */
@objc(NfcPlugin)
public class NfcPlugin: CAPPlugin {
    public let tag = "Nfc"
    public let nfcTagScannedEvent = "nfcTagScanned"
    public let scanSessionCanceledEvent = "scanSessionCanceled"
    public let scanSessionErrorEvent = "scanSessionError"
    public let errorNoTagDetected = "No NFC tag was detected."
    public let errorNdefNotSupported = "The NFC tag does not support NDEF tag technology."
    public let errorIosNotSupported = "This iOS version is not supported."
    private var _implementation: Any?

    @available(iOS 13.0, *)
    fileprivate var implementation: Nfc? {
        // swiftlint:disable:next force_cast
        return _implementation as! Nfc?
    }

    override public func load() {
        if #available(iOS 13.0, *) {
            _implementation = Nfc(plugin: self)
        } else {
            print("\(tag): \(errorIosNotSupported)")
        }
    }

    @objc override public func checkPermissions(_ call: CAPPluginCall) {
        call.resolve([
            "nfc": "granted"
        ])
    }

    @objc override public func requestPermissions(_ call: CAPPluginCall) {
        call.resolve([
            "nfc": "granted"
        ])
    }

    @objc func startScanSession(_ call: CAPPluginCall) {
        if #available(iOS 13.0, *) {
            let alertMessage = call.getString("alertMessage", "")

            implementation?.startScanSession(alertMessage: alertMessage)
            call.resolve()
        } else {
            call.reject(errorIosNotSupported)
        }
    }

    @objc func stopScanSession(_ call: CAPPluginCall) {
        if #available(iOS 13.0, *) {
            let errorMessage = call.getString("errorMessage")
            
            implementation?.stopScanSession(errorMessage: errorMessage)
            call.resolve()
        } else {
            call.reject(errorIosNotSupported)
        }
    }

    @objc func write(_ call: CAPPluginCall) {
        if #available(iOS 13.0, *) {
            let jsonMessage = call.getObject("message", JSObject())
            let message = NfcHelper.createNdefMessageFromJsonObject(json: jsonMessage)

            implementation?.write(message: message, completion: { errorMessage in
                if let errorMessage = errorMessage {
                    call.reject(errorMessage)
                    return
                }
                call.resolve()
            })
        } else {
            call.reject(errorIosNotSupported)
        }
    }

    @objc func makeReadOnly(_ call: CAPPluginCall) {
        if #available(iOS 13.0, *) {
            implementation?.makeReadOnly(completion: { errorMessage in
                if let errorMessage = errorMessage {
                    call.reject(errorMessage)
                    return
                }
                call.resolve()
            })
        } else {
            call.reject(errorIosNotSupported)
        }
    }

    @objc func isSupported(_ call: CAPPluginCall) {
        if #available(iOS 13.0, *) {
            let isSupported = implementation?.isSupported()
            call.resolve([
                "isSupported": isSupported ?? false
            ])
        } else {
            call.reject(errorIosNotSupported)
        }
    }

    @objc func isEnabled(_ call: CAPPluginCall) {
        call.unimplemented()
    }

    @objc func openSettings(_ call: CAPPluginCall) {
        call.unimplemented()
    }

    func notifyNfcTagScannedListener(nfcTag: JSObject) {
        var result = JSObject()
        result["nfcTag"] = nfcTag
        notifyListeners(nfcTagScannedEvent, data: result)
    }
    
    func notifyScanSessionCanceledListener() {
        notifyListeners(scanSessionCanceledEvent, data: nil)
    }
    
    func notifyScanSessionErrorListener(message: String) {
        var result = JSObject()
        result["message"] = message
        notifyListeners(scanSessionErrorEvent, data: result)
    }
}
