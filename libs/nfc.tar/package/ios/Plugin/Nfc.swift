import Foundation
import CoreNFC

@available(iOS 13.0, *)
@objc public class Nfc: NSObject {

    private let plugin: NfcPlugin
    private var session: NFCTagReaderSession?

    init(plugin: NfcPlugin) {
        self.plugin = plugin
    }

    public func startScanSession(alertMessage: String?) {
        session = NFCTagReaderSession(pollingOption: [.iso14443, .iso15693, .iso18092], delegate: self)
        session?.alertMessage = alertMessage ?? ""
        session?.begin()
    }

    public func stopScanSession(errorMessage: String?) {
        if let errorMessage = errorMessage {
            session?.invalidate(errorMessage: errorMessage)
        } else {
            session?.invalidate()
        }
    }

    public func write(message: NFCNDEFMessage, completion: @escaping (String?) -> Void) {
        guard let tag = session?.connectedTag else {
            completion(plugin.errorNoTagDetected)
            return
        }
        guard let ndefTag = NfcHelper.getNfcNdefTagFromNfcTag(tag: tag) else {
            completion(plugin.errorNdefNotSupported)
            return
        }
        ndefTag.writeNDEF(message, completionHandler: { error in
            if let error = error {
                completion(error.localizedDescription)
                return
            }
            completion(nil)
        })
    }

    public func makeReadOnly(completion: @escaping (String?) -> Void) {
        guard let tag = session?.connectedTag else {
            completion(plugin.errorNoTagDetected)
            return
        }
        guard let ndefTag = NfcHelper.getNfcNdefTagFromNfcTag(tag: tag) else {
            completion(plugin.errorNdefNotSupported)
            return
        }
        ndefTag.writeLock(completionHandler: { error in
            if let error = error {
                completion(error.localizedDescription)
                return
            }
            completion(nil)
        })
    }

    public func isSupported() -> Bool {
        return NFCTagReaderSession.readingAvailable
    }
}

@available(iOS 13.0, *)
extension Nfc: NFCTagReaderSessionDelegate {

    public func tagReaderSessionDidBecomeActive(_ session: NFCTagReaderSession) {
        // no op
    }

    public func tagReaderSession(_ session: NFCTagReaderSession, didInvalidateWithError error: Error) {
        let message = error.localizedDescription
        if message.contains("Session invalidated by user") {
            self.plugin.notifyScanSessionCanceledListener()
        } else {
            self.plugin.notifyScanSessionErrorListener(message: message)
        }
    }

    public func tagReaderSession(_ session: NFCTagReaderSession, didDetect tags: [NFCTag]) {
        let firstTag = tags.first!
        session.connect(to: firstTag) { error in
            guard error == nil else {
                session.invalidate(errorMessage: "Could not connect to tag.")
                return
            }

            var status: NFCNDEFStatus?
            var ndefMessage: NFCNDEFMessage?
            var capacity: Int?

            let group = DispatchGroup()
            if let ndefTag = NfcHelper.getNfcNdefTagFromNfcTag(tag: firstTag) {
                group.enter()
                ndefTag.readNDEF(completionHandler: { ndefMessageResult, _ in
                    ndefMessage = ndefMessageResult
                    group.leave()
                })
                group.enter()
                ndefTag.queryNDEFStatus(completionHandler: { statusResult, capacityResult, _ in
                    status = statusResult
                    capacity = capacityResult
                    group.leave()
                })
            }

            group.notify(queue: .main) {
                let nfcTagResult = NfcHelper.createReadingResultForNdefTag(tag: firstTag, status: status, capacity: capacity, message: ndefMessage)
                self.plugin.notifyNfcTagScannedListener(nfcTag: nfcTagResult)
            }
        }
    }
}
