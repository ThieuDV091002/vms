package io.capawesome.capacitorjs.plugins.nfc;

import android.content.Intent;
import android.nfc.NdefMessage;
import android.util.Log;
import androidx.activity.result.ActivityResult;
import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.ActivityCallback;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.getcapacitor.annotation.Permission;
import java.util.List;
import org.json.JSONException;
import org.json.JSONObject;

@CapacitorPlugin(name = "Nfc", permissions = @Permission(strings = {}, alias = "nfc"))
public class NfcPlugin extends Plugin {

    public static final String TAG = "NfcPlugin";

    public static final String NFC_TAG_SCANNED_EVENT = "nfcTagScanned";
    public static final String NFC_SCAN_SESSION_ERROR_EVENT = "scanSessionError";
    public static final String ERROR_NO_TAG_DETECTED = "No NFC tag was detected.";
    public static final String ERROR_NDEF_NOT_SUPPORTED = "The NFC tag does not support NDEF tag technology.";
    public static final String ERROR_MESSAGE_SIZE_EXCEEDED = "The maximum message size of the NFC tag was exceeded.";
    public static final String ERROR_TAG_READONLY = "The tag is read-only.";

    private Nfc implementation;

    @Override
    public void load() {
        try {
            implementation = new Nfc(this);
        } catch (Exception ex) {
            String message = ex.getLocalizedMessage();
            Log.e(TAG, message);
        }
    }

    @Override
    protected void handleOnPause() {
        try {
            super.handleOnPause();
            implementation.handleOnPause();
        } catch (Exception ex) {
            String message = ex.getLocalizedMessage();
            Log.e(TAG, message);
        }
    }

    @Override
    protected void handleOnResume() {
        try {
            super.handleOnResume();
            implementation.handleOnResume();
        } catch (Exception ex) {
            String message = ex.getLocalizedMessage();
            Log.e(TAG, message);
        }
    }

    @Override
    protected void handleOnNewIntent(Intent intent) {
        try {
            super.handleOnNewIntent(intent);
            implementation.handleOnNewIntent(intent);
        } catch (Exception ex) {
            String message = ex.getLocalizedMessage();
            Log.e(TAG, message);
        }
    }

    @PluginMethod
    public void startScanSession(PluginCall call) {
        try {
            List<String> techTypes = null;
            try {
                techTypes = call.getArray("techTypes").toList();
            } catch (JSONException ex) {}
            List<String> mimeTypes = null;
            try {
                mimeTypes = call.getArray("mimeTypes").toList();
            } catch (JSONException ex) {}

            implementation.startScanSession(techTypes, mimeTypes);
            call.resolve();
        } catch (Exception ex) {
            String message = ex.getLocalizedMessage();
            Log.e(TAG, message);
            call.reject(message);
        }
    }

    @PluginMethod
    public void stopScanSession(PluginCall call) {
        try {
            implementation.stopScanSession();
            call.resolve();
        } catch (Exception ex) {
            String message = ex.getLocalizedMessage();
            Log.e(TAG, message);
            call.reject(message);
        }
    }

    @PluginMethod
    public void write(PluginCall call) {
        try {
            JSObject jsonMessage = call.getObject("message", new JSObject());

            NdefMessage message = NfcHelper.createNdefMessageFromJsonObject(jsonMessage);
            implementation.write(message);
            call.resolve();
        } catch (Exception ex) {
            String message = ex.getLocalizedMessage();
            Log.e(TAG, message);
            call.reject(message);
        }
    }

    @PluginMethod
    public void isSupported(PluginCall call) {
        try {
            JSObject ret = new JSObject();
            ret.put("isSupported", implementation.isSupported());
            call.resolve(ret);
        } catch (Exception ex) {
            String message = ex.getLocalizedMessage();
            Log.e(TAG, message);
            call.reject(message);
        }
    }

    @PluginMethod
    public void isEnabled(PluginCall call) {
        try {
            JSObject ret = new JSObject();
            ret.put("isEnabled", implementation.isEnabled());
            call.resolve(ret);
        } catch (Exception ex) {
            String message = ex.getLocalizedMessage();
            Log.e(TAG, message);
            call.reject(message);
        }
    }

    @PluginMethod
    public void openSettings(PluginCall call) {
        try {
            implementation.openSettings(call);
        } catch (Exception ex) {
            String message = ex.getLocalizedMessage();
            Log.e(TAG, message);
            call.reject(message);
        }
    }

    @ActivityCallback
    public void openSettingsResult(PluginCall call, ActivityResult result) {
        try {
            if (call == null) {
                Log.d(TAG, "openSettingsResult was called with empty call parameter.");
                return;
            }
            call.resolve();
        } catch (Exception ex) {
            String message = ex.getLocalizedMessage();
            Log.e(TAG, message);
        }
    }

    public void notifyNfcTagScannedListener(JSONObject nfcTag) {
        try {
            JSObject result = new JSObject();
            result.put("nfcTag", nfcTag);
            notifyListeners(NFC_TAG_SCANNED_EVENT, result);
        } catch (Exception ex) {
            String message = ex.getLocalizedMessage();
            Log.e(TAG, message);
        }
    }

    public void notifyScanSessionErrorListener(String message) {
        try {
            JSObject result = new JSObject();
            result.put("message", message);
            notifyListeners(NFC_SCAN_SESSION_ERROR_EVENT, result);
        } catch (Exception ex) {
            Log.e(TAG, ex.getLocalizedMessage());
        }
    }
}
