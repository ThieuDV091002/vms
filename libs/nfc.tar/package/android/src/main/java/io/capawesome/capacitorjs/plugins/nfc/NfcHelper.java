package io.capawesome.capacitorjs.plugins.nfc;

import android.nfc.NdefMessage;
import android.nfc.NdefRecord;
import android.nfc.Tag;
import android.nfc.tech.IsoDep;
import android.nfc.tech.MifareClassic;
import android.nfc.tech.MifareUltralight;
import android.nfc.tech.Ndef;
import android.nfc.tech.NfcA;
import android.nfc.tech.NfcB;
import android.nfc.tech.NfcBarcode;
import android.nfc.tech.NfcF;
import android.nfc.tech.NfcV;
import android.os.Parcelable;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import java.util.ArrayList;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class NfcHelper {

    public static JSONObject createReadingResultForNdefTag(Tag tag, @Nullable Parcelable rawMessage) throws JSONException {
        JSONArray tagId = convertByteArrayToJsonArray(tag.getId());
        JSONArray techTypes = new JSONArray(mapTagTechClassNamesToTypes(tag.getTechList()));
        JSONObject message = createJsonObjectFromRawNdefMessage(rawMessage);

        JSONObject result = new JSONObject();
        result.put("id", tagId);
        result.put("message", message);
        result.put("techTypes", techTypes);

        Ndef ndef = Ndef.get(tag);
        if (ndef != null) {
            String type = mapNdefTagTypeToResultType(ndef.getType());

            result.put("canMakeReadOnly", ndef.canMakeReadOnly());
            result.put("isWritable", ndef.isWritable());
            result.put("maxSize", ndef.getMaxSize());
            result.put("type", type);
        }

        NfcA nfca = NfcA.get(tag);
        if (nfca != null) {
            JSONArray atqa = convertByteArrayToJsonArray(nfca.getAtqa());
            JSONArray sak = convertByteArrayToJsonArray(convertShortToByteArray(nfca.getSak()));

            result.put("atqa", atqa);
            result.put("sak", sak);
        }

        NfcB nfcb = NfcB.get(tag);
        if (nfcb != null) {
            JSONArray applicationData = convertByteArrayToJsonArray(nfcb.getApplicationData());
            JSONArray protocolInfo = convertByteArrayToJsonArray(nfcb.getProtocolInfo());

            result.put("applicationData", applicationData);
            result.put("protocolInfo", protocolInfo);
        }

        NfcF nfcf = NfcF.get(tag);
        if (nfcf != null) {
            JSONArray manufacturer = convertByteArrayToJsonArray(nfcf.getManufacturer());
            JSONArray systemCode = convertByteArrayToJsonArray(nfcf.getManufacturer());

            result.put("manufacturer", manufacturer);
            result.put("systemCode", systemCode);
        }

        NfcV nfcv = NfcV.get(tag);
        if (nfcv != null) {
            JSONArray dsfId = convertByteArrayToJsonArray(new byte[] { nfcv.getDsfId() });
            JSONArray responseFlags = convertByteArrayToJsonArray(new byte[] { nfcv.getResponseFlags() });

            result.put("dsfId", dsfId);
            result.put("responseFlags", responseFlags);
        }

        IsoDep isoDep = IsoDep.get(tag);
        if (isoDep != null) {
            JSONArray hiLayerResponse = convertByteArrayToJsonArray(isoDep.getHiLayerResponse());
            JSONArray historicalBytes = convertByteArrayToJsonArray(isoDep.getHistoricalBytes());

            result.put("hiLayerResponse", hiLayerResponse);
            result.put("historicalBytes", historicalBytes);
        }

        MifareClassic mifareClassic = MifareClassic.get(tag);
        if (mifareClassic != null) {
            int blockCount = mifareClassic.getBlockCount();
            int sectorCount = mifareClassic.getSectorCount();
            int size = mifareClassic.getSize();
            String type = mapMifareClassicTagTypeToResultType(mifareClassic.getType());

            result.put("blockCount", blockCount);
            result.put("sectorCount", sectorCount);
            result.put("size", size);
            result.put("type", type);
        }

        MifareUltralight mifareUltralight = MifareUltralight.get(tag);
        if (mifareUltralight != null) {
            String type = mapMifareUltralightTagTypeToResultType(mifareUltralight.getType());

            result.put("type", type);
        }

        NfcBarcode nfcBarcode = NfcBarcode.get(tag);
        if (nfcBarcode != null) {
            JSONArray barcode = convertByteArrayToJsonArray(nfcBarcode.getBarcode());

            result.put("barcode", barcode);
        }

        return result;
    }

    public static JSONObject createReadingResultForNdefFormatableTag(Tag tag) throws JSONException {
        JSONArray tagId = convertByteArrayToJsonArray(tag.getId());
        JSONArray techTypes = new JSONArray(mapTagTechClassNamesToTypes(tag.getTechList()));

        JSONObject result = new JSONObject();
        result.put("id", tagId);
        result.put("techTypes", techTypes);
        return result;
    }

    public static NdefMessage createNdefMessageFromJsonObject(@NonNull JSONObject jsonMessage) throws JSONException {
        JSONArray jsonRecords = jsonMessage.getJSONArray("records");
        NdefRecord[] records = new NdefRecord[jsonRecords.length()];
        for (int i = 0; i < jsonRecords.length(); i++) {
            JSONObject jsonRecord = (JSONObject) jsonRecords.get(i);
            short tnf = (short) jsonRecord.getInt("tnf");
            byte[] type = convertJsonArrayToByteArray(jsonRecord.getJSONArray("type"));
            byte[] id = convertJsonArrayToByteArray(jsonRecord.getJSONArray("id"));
            byte[] payload = convertJsonArrayToByteArray(jsonRecord.getJSONArray("payload"));
            NdefRecord record = new NdefRecord(tnf, type, id, payload);
            records[i] = record;
        }
        return new NdefMessage(records);
    }

    private static JSONObject createJsonObjectFromRawNdefMessage(@Nullable Parcelable rawMessage) throws JSONException {
        JSONObject jsonObject = new JSONObject();
        if (rawMessage == null) {
            return jsonObject;
        }
        NdefMessage ndefMessage = (NdefMessage) rawMessage;
        NdefRecord[] ndefRecords = ndefMessage.getRecords();
        JSONArray records = createJsonArrayFromNdefRecords(ndefRecords);
        jsonObject.put("records", records);
        return jsonObject;
    }

    private static JSONArray createJsonArrayFromNdefRecords(@NonNull NdefRecord[] ndefRecords) throws JSONException {
        List<JSONObject> list = new ArrayList();
        for (NdefRecord ndefRecord : ndefRecords) {
            list.add(createJsonObjectFromNdefRecord(ndefRecord));
        }
        return new JSONArray(list);
    }

    private static JSONObject createJsonObjectFromNdefRecord(NdefRecord record) throws JSONException {
        JSONObject ret = new JSONObject();
        ret.put("id", convertByteArrayToJsonArray(record.getId()));
        ret.put("type", convertByteArrayToJsonArray(record.getType()));
        ret.put("payload", convertByteArrayToJsonArray(record.getPayload()));
        ret.put("tnf", record.getTnf());
        return ret;
    }

    private static List<String> mapTagTechClassNamesToTypes(String[] techClassNames) {
        List<String> resultTypes = new ArrayList();
        for (String techClassName : techClassNames) {
            resultTypes.add(mapTagTechClassNameToType(techClassName));
        }
        return resultTypes;
    }

    private static String mapTagTechClassNameToType(String techClassName) {
        String resultType = techClassName;
        if (techClassName.equals("android.nfc.tech.NfcA")) {
            resultType = "NFC_A";
        } else if (techClassName.equals("android.nfc.tech.NfcB")) {
            resultType = "NFC_B";
        } else if (techClassName.equals("android.nfc.tech.NfcF")) {
            resultType = "NFC_F";
        } else if (techClassName.equals("android.nfc.tech.NfcV")) {
            resultType = "NFC_V";
        } else if (techClassName.equals("android.nfc.tech.IsoDep")) {
            resultType = "ISO_DEP";
        } else if (techClassName.equals("android.nfc.tech.Ndef")) {
            resultType = "NDEF";
        } else if (techClassName.equals("android.nfc.tech.MifareClassic")) {
            resultType = "MIFARE_CLASSIC";
        } else if (techClassName.equals("android.nfc.tech.MifareUltralight")) {
            resultType = "MIFARE_ULTRALIGHT";
        } else if (techClassName.equals("android.nfc.tech.NfcBarcode")) {
            resultType = "NFC_BARCODE";
        } else if (techClassName.equals("android.nfc.tech.NdefFormatable")) {
            resultType = "NDEF_FORMATABLE";
        }
        return resultType;
    }

    private static String mapNdefTagTypeToResultType(String tagTyp) {
        String resultType = tagTyp;
        if (tagTyp.equals(Ndef.NFC_FORUM_TYPE_1)) {
            resultType = "NFC_FORUM_TYPE_1";
        } else if (tagTyp.equals(Ndef.NFC_FORUM_TYPE_2)) {
            resultType = "NFC_FORUM_TYPE_2";
        } else if (tagTyp.equals(Ndef.NFC_FORUM_TYPE_3)) {
            resultType = "NFC_FORUM_TYPE_3";
        } else if (tagTyp.equals(Ndef.NFC_FORUM_TYPE_4)) {
            resultType = "NFC_FORUM_TYPE_4";
        } else if (tagTyp.equals(Ndef.MIFARE_CLASSIC)) {
            resultType = "MIFARE_CLASSIC";
        }
        return resultType;
    }

    private static String mapMifareClassicTagTypeToResultType(int tagTyp) {
        switch (tagTyp) {
            case MifareClassic.TYPE_PLUS:
                return "MIFARE_PLUS";
            case MifareClassic.TYPE_PRO:
                return "MIFARE_PRO";
            default:
                return "MIFARE_CLASSIC";
        }
    }

    private static String mapMifareUltralightTagTypeToResultType(int tagTyp) {
        switch (tagTyp) {
            case MifareUltralight.TYPE_ULTRALIGHT_C:
                return "MIFARE_ULTRALIGHT_C";
            default:
                return "MIFARE_ULTRALIGHT";
        }
    }

    private static JSONArray convertByteArrayToJsonArray(byte[] bytes) {
        JSONArray ret = new JSONArray();
        for (byte _byte : bytes) {
            ret.put(_byte);
        }
        return ret;
    }

    private static byte[] convertJsonArrayToByteArray(JSONArray json) throws JSONException {
        byte[] bytes = new byte[json.length()];
        for (int i = 0; i < json.length(); i++) {
            bytes[i] = (byte) json.getInt(i);
        }
        return bytes;
    }

    private static byte[] convertShortToByteArray(short bytes) {
        byte[] byteArray = new byte[2];
        byteArray[0] = (byte) (bytes & 0xff);
        byteArray[1] = (byte) ((bytes >> 8) & 0xff);
        return byteArray;
    }
}
